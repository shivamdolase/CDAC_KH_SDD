package recept_management.example.a1;
import java.util.*;

public class RecipeUtil {
	Scanner sc=new Scanner(System.in);
	
	public void register() {
		System.out.println("Enter user name:");
		String name=sc.nextLine();
		//cuser=new User(username);
	}
	public void addRecipe() {
		System.out.println("enter recipe type");
		String str=sc.next();
		if(str.equalsIgnoreCase("nonveg")) {
			Recipe rp=new NonVegeterianRecipe();
			System.out.println("enter name");
			rp.setName(sc.nextLine());
			System.out.println("enter recipe id");
			rp.setRecipeId(sc.nextInt());
			System.out.println("enter number of ingredience");
			List<String> ingredients=Arrays.asList(sc.nextLine().split(","));
			
			
			rp.setIngredients(ingredients);
			System.out.println("enter prep time");
			rp.setPreparationTime(sc.nextInt());
			System.out.println("indstructions");
			rp.setInstructions(sc.nextLine());
			RecipeManager manager=new RecipeManager ();
			manager.addRecipe(rp);
			
		}
		else if(str.equalsIgnoreCase("nonveg")) {
			Recipe rp=new NonVegeterianRecipe();
			System.out.println("enter name");
			rp.setName(sc.nextLine());
			System.out.println("enter recipe id");
			rp.setRecipeId(sc.nextInt());
			System.out.println("enter number of ingredience");
			List<String> ingredients=Arrays.asList(sc.nextLine().split(","));
			
			
			rp.setIngredients(ingredients);
			System.out.println("enter prep time");
			rp.setPreparationTime(sc.nextInt());
			System.out.println("indstructions");
			rp.setInstructions(sc.nextLine());
			RecipeManager manager=new RecipeManager();
			manager.addRecipe(rp);
		}
		
		
	}
	public void searchRecipe() {
		System.out.println("Enter name");
		RecipeManager manager=new RecipeManager();
		String searchName=sc.nextLine();
		List<Recipe> foundrecipes=manager.searchRecipes();
;		for (Recipe foundrecipe:foundrecipes) {
			System.out.println("foundReceipe.getDetails()");
		}
	}
	public void displayAll() {
		RecipeManager manager=new RecipeManager ();
		manager.displayRecipe();
	}
	

	public void menu() {
		System.out.println("0.Exit");
		System.out.println("1.Register User");
		System.out.println("2.Add Recipe");
		System.out.println("3.Search Recipe");
		System.out.println("4.Display All Receipe");
	}
}
//case 1:
//	rp.register();
//	break;
//case 2:
//	rp.addRecipe();
//	break;
//case 3:
//	rp.searchRecipe();
//	break;
//case 4:
//	rp.dispalyAll();