package recept_management.example.a1;
import java.util.*;

public class User {
	
	private String username;
	private List<Recipe> saveRecipes;
	
	public User(String username) {
		this.username=username;
		this.saveRecipes=new ArrayList<>();
	}
	public String getUsername() {
		return username;
	}
	public List<Recipe> getSavedrecipes(){
		return saveRecipes;
	}
	public void saveRecipe(Recipe rc) {
		saveRecipes.add(rc);
		rc.saveReceipt();
		
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", saveRecipes=" + saveRecipes + "]";
	}
}
