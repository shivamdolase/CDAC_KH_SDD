package recept_management.example.a1;
import java.util.*;

public class Recipe {
	
	private String name;
	private int recipeId;
	private List<String> ingredients=new ArrayList<>();
	private String instructions;
	private int preparationTime;
	public Recipe() {
		this("",0,null,"",0);
	}
	public Recipe(String name, int recipeId, List<String> ingredients, String instructions, int preparationTime) {
		this.name = name;
		this.recipeId = recipeId;
		this.ingredients = ingredients;
		this.instructions = instructions;
		this.preparationTime = preparationTime;
	}
	
	public void saveReceipt() {
		System.out.println("Saving recipe...");
		
	}
	public void shareReceeipt() {
		System.out.println("Sharing recipe...");
	}
	public String getDetails(){
		String str= this.toString();
		return str;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(int recipeId) {
		this.recipeId = recipeId;
	}
	public List<String> getIngredients() {
		return ingredients;
	}
	public void setIngredients(List<String> ingredients) {
		this.ingredients = ingredients;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	public int getPreparationTime() {
		return preparationTime;
	}
	public void setPreparationTime(int preparationTime) {
		this.preparationTime = preparationTime;
	}
	
	@Override
	public String toString() {
		return "Recipe [name=" + name + ", recipeId=" + recipeId + ", ingredients=" + ingredients + 
				 ", instructions=" + instructions + ", preparationTime=" + preparationTime + "]";
	}
	
}
