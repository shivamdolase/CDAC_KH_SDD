package recept_management.example.a1;
import java.util.*;

public class RecipeManager {
	List<Recipe> recipes;
	Map<User,List<Recipe>> userRecipes;
	
	public RecipeManager() {
		recipes=new ArrayList<>();
		userRecipes=new HashMap<>();
		
	}
	public void addRecipe(Recipe rc) {
		recipes.add(rc);
	}
	public void registerUser(User user) {
		userRecipes.put(user, new ArrayList<>());
	}
	public void saveReciptForUser(User user,Recipe recipe) {
		
		user.saveRecipe(recipe);
		userRecipes.get(user).add(recipe);
	}

	public List<Recipe> searchRecipes() {
		
		return null;
	}

	public void displayRecipe() {
		
		
	}
}