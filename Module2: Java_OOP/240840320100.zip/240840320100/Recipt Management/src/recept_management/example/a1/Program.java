package recept_management.example.a1;
import java.util.Scanner;
public class Program {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		RecipeUtil rp=new RecipeUtil();
		System.out.println("Welcom user:");
		
		rp.menu();
		boolean status=true;
		System.out.println("selsect a option:");
		while(status) {
			int option=sc.nextInt();
			switch(option) {
			case 0:
				System.out.println("Exiting...");
				status=false;
				sc.close();
				break;
			case 1:
				rp.register();
				break;
			case 2:
				rp.addRecipe();
				break;
			case 3:
				rp.searchRecipe();
				break;
			case 4:
				rp.displayAll();
				break;
			default:
				System.out.println("Enter another choice :");
				break;
				
			}
			rp.menu();
			System.out.println("selsect a option:");
			
		}
	}
}
