package recept_management.example.a1;

import java.util.List;

public class NonVegeterianRecipe extends Recipe{

	public NonVegeterianRecipe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NonVegeterianRecipe(String name, int recipeId, List<String> ingredients, String instructions,
			int preparationTime) {
		super(name, recipeId, ingredients, instructions, preparationTime);
		// TODO Auto-generated constructor stub
	}
	public void saveReceipt() {
		System.out.println("Saving NonVegetrian recipe...");
		
	}
	public void shareReceeipt() {
		System.out.println("Sharing NonVegetrian recipe...");
	}
	
	
}
