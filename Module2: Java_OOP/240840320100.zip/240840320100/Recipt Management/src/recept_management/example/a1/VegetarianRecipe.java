package recept_management.example.a1;

import java.util.List;

public class VegetarianRecipe extends Recipe{
	

	public VegetarianRecipe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VegetarianRecipe(String name, int recipeId, List<String> ingredients, String instructions,
			int preparationTime) {
		super(name, recipeId, ingredients, instructions, preparationTime);
		// TODO Auto-generated constructor stub
	}
	public void saveReceipt() {
		System.out.println("Saving Vegetrian recipe...");
		
	}
	public void shareReceeipt() {
		System.out.println("Sharing Vegetrian recipe...");
	}
	
	
}
